package vista;

import controlador.HistorialVentas;
import modelo.Venta;
import modelo.Producto; // Asegúrate de importar Producto si no lo has hecho
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import vista.frmAdmin;
import javax.swing.JTable; // Importa JTable
import java.awt.Point; // Importa Point
import javax.swing.JOptionPane;
import javax.swing.SwingConstants; // Para alinear texto si es necesario

public class frmHistorialVentas extends javax.swing.JFrame {

    private HistorialVentas historialVentas;
    // Declara jTable1 aquí para que sea accesible en toda la clase
    private javax.swing.JTable jTable1; 

    public frmHistorialVentas() {
        // Llama a initComponents primero para que los componentes del diseñador se creen
        initComponents();
        this.setLocationRelativeTo(null); // Centra la ventana

        historialVentas = new HistorialVentas();

        // --- INICIALIZACIÓN Y CONFIGURACIÓN PERSONALIZADA DE JTABLE ---
        // Aquí es donde creamos y configuramos jTable1 con el tooltip.
        // Asegúrate de que el jTable1 de tu initComponents() NO esté creando una nueva instancia,
        // sino que simplemente lo declare y luego lo uses aquí.
        jTable1 = new JTable(new DefaultTableModel(
            new Object [][] {
                // Puedes dejar esto vacío, el cargarTablaHistorialVentas lo llenará
            },
            new String [] {
                "Fecha de compra", "ID de venta", "Cliente", "Productos vendidos", "Total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        }) {
            // Sobrescribir el método getToolTipText para mostrar el contenido completo
            @Override
            public String getToolTipText(MouseEvent e) {
                String tip = null;
                Point p = e.getPoint(); // Obtener la posición del mouse
                int rowIndex = rowAtPoint(p); // Obtener el índice de la fila
                int colIndex = columnAtPoint(p); // Obtener el índice de la columna
                
                // Convertir el índice de la vista a índice del modelo si la tabla se ordena
                colIndex = convertColumnIndexToModel(colIndex);

                // Asumiendo que la columna "Productos vendidos" es el índice 3 del modelo
                if (rowIndex != -1 && colIndex == 3) { 
                    Object value = getValueAt(rowIndex, colIndex);
                    if (value != null) {
                        // Importante: Si usas HTML en la celda (con <br>), el tooltip lo interpreta literalmente.
                        // Debemos limpiar el HTML y usar "\n" para saltos de línea en el tooltip.
                        tip = value.toString().replace("<html>", "")
                                             .replace("</html>", "")
                                             .replace("<br>", "\n");
                    }
                }
                return tip;
            }
        };
        // Establecer el modelo en el JScrollPane después de crear el JTable personalizado
        jScrollPane1.setViewportView(jTable1);
        
        // Ajustar el ancho preferido de la columna de productos vendidos
        // Puedes experimentar con este valor para que se vea bien en tu interfaz
        jTable1.getColumnModel().getColumn(3).setPreferredWidth(350); 
        // También puedes ajustar la altura de las filas si usas HTML y múltiples líneas
        jTable1.setRowHeight(jTable1.getRowHeight() * 2); // Ejemplo: Duplicar la altura de las filas

        // --- FIN DE LA CONFIGURACIÓN PERSONALIZADA DE JTABLE ---

        // Carga los datos en la tabla después de que jTable1 esté completamente configurado
        cargarTablaHistorialVentas(); 



        // Este MouseListener es para el doble clic, si lo quieres mantener
        jTable1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) { // Detectar doble clic
                    int selectedRow = jTable1.getSelectedRow();
                    if (selectedRow != -1) { 
                        // Obtener el ID de la venta. Es importante obtenerlo del modelo, no de la vista,
                        // si la tabla puede ser ordenada (jTable1.convertRowIndexToModel(selectedRow))
                        int modelRow = jTable1.convertRowIndexToModel(selectedRow);
                        int idVentaSeleccionada = (int) jTable1.getModel().getValueAt(modelRow, 1);
                        
                        Venta ventaSeleccionada = null;
                        for (Venta venta : historialVentas.obtenerTodasLasVentas()) {
                            if (venta.getIdVenta() == idVentaSeleccionada) {
                                ventaSeleccionada = venta;
                                break;
                            }
                        }

                        // Si no tienes frmDetalleVenta, puedes mostrar un JOptionPane.showMessageDialog aquí
                        if (ventaSeleccionada != null) {
                            JOptionPane.showMessageDialog(frmHistorialVentas.this, 
                                "Detalles de la Venta:\n" +
                                "ID Venta: " + ventaSeleccionada.getIdVenta() + "\n" +
                                "Fecha: " + ventaSeleccionada.getFechaCompraFormateada() + "\n" +
                                "Cliente: " + ventaSeleccionada.getNombreCliente() + "\n" +
                                "Productos:\n" + ventaSeleccionada.getProductosVendidosAsString().replace("<html>", "").replace("</html>", "").replace("<br>", "\n") + "\n" +
                                "Total: $" + String.format("%,.2f", ventaSeleccionada.getTotalVenta()),
                                "Detalle de Venta", JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                }
            }
        });
    }
    
    private void cargarTablaHistorialVentas() {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0);

        for (Venta venta : historialVentas.obtenerTodasLasVentas()) {
            model.addRow(new Object[]{
                venta.getFechaCompraFormateada(),
                venta.getIdVenta(),
                venta.getNombreCliente(),
                venta.getProductosVendidosAsString(),
                String.format("%,.2f", venta.getTotalVenta())
            });
        }
    }



    @SuppressWarnings("unchecked")
    
   // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
 

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnVolverAlPanel = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setText("Historial de ventas");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Fecha de compra", "ID de venta", "Cliente", "Productos vendidos", "Total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        btnVolverAlPanel.setText("Volver al panel de administrador");
        btnVolverAlPanel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverAlPanelActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1))
            .addGroup(layout.createSequentialGroup()
                .addGap(140, 140, 140)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(340, Short.MAX_VALUE)
                .addComponent(btnVolverAlPanel)
                .addGap(307, 307, 307))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addComponent(btnVolverAlPanel)
                .addContainerGap(119, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVolverAlPanelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverAlPanelActionPerformed
        // TODO add your handling code here:
        new frmAdmin().setVisible(true); // Abre el formulario de administrador
        this.dispose(); // Cierra el formulario actual
    }//GEN-LAST:event_btnVolverAlPanelActionPerformed

   public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmHistorialVentas().setVisible(true);
            }
        });
    }
  
       // Variables declaration - do not modify                     
    private javax.swing.JButton btnVolverAlPanel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
   // private javax.swing.JTable jTable1;
    // End of variables declaration    
/*
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnVolverAlPanel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
*/

}
