package vista;

import controlador.HistorialVentas;
import java.awt.Color;
import modelo.Venta;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTable; // Importa JTable
import java.awt.Point; // Importa Point
import javax.swing.JOptionPane;
import modelo.Sesion;

public class frmHistorialVentas extends javax.swing.JFrame {

    private HistorialVentas historialVentas;
    // Declara jTable1 aquí para que sea accesible en toda la clase

    public frmHistorialVentas() {
        // Llama a initComponents primero para que los componentes del diseñador se creen
        initComponents();
        this.setLocationRelativeTo(null); // Centra la ventana
        jScrollPane1.getViewport().setBackground(Color.WHITE);
        jTable1.setBackground(Color.WHITE);

        historialVentas = new HistorialVentas();

        // --- INICIALIZACIÓN Y CONFIGURACIÓN PERSONALIZADA DE JTABLE ---
        // Aquí es donde creamos y configuramos jTable1 con el tooltip.
        // Asegúrate de que el jTable1 de tu initComponents() NO esté creando una nueva instancia,
        // sino que simplemente lo declare y luego lo uses aquí.
        jTable1 = new JTable(new DefaultTableModel(
                new Object[][]{ // Puedes dejar esto vacío, el cargarTablaHistorialVentas lo llenará
                },
                new String[]{
                    "Fecha de compra", "ID de venta", "Cliente", "Productos vendidos", "Total"
                }
        ) {
            boolean[] canEdit = new boolean[]{
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        }) {
            // Sobrescribir el método getToolTipText para mostrar el contenido completo
            @Override
            public String getToolTipText(MouseEvent e) {
                String tip = null;
                Point p = e.getPoint(); // Obtener la posición del mouse
                int rowIndex = rowAtPoint(p); // Obtener el índice de la fila
                int colIndex = columnAtPoint(p); // Obtener el índice de la columna

                // Convertir el índice de la vista a índice del modelo si la tabla se ordena
                colIndex = convertColumnIndexToModel(colIndex);

                // Asumiendo que la columna "Productos vendidos" es el índice 3 del modelo
                if (rowIndex != -1 && colIndex == 3) {
                    Object value = getValueAt(rowIndex, colIndex);
                    if (value != null) {
                        // Importante: Si usas HTML en la celda (con <br>), el tooltip lo interpreta literalmente.
                        // Debemos limpiar el HTML y usar "\n" para saltos de línea en el tooltip.
                        tip = value.toString().replace("<html>", "")
                                .replace("</html>", "")
                                .replace("<br>", "\n");
                    }
                }
                return tip;
            }
        };
        // Establecer el modelo en el JScrollPane después de crear el JTable personalizado
        jScrollPane1.setViewportView(jTable1);

        // Ajustar el ancho preferido de la columna de productos vendidos
        // Puedes experimentar con este valor para que se vea bien en tu interfaz
        jTable1.getColumnModel().getColumn(3).setPreferredWidth(350);
        // También puedes ajustar la altura de las filas si usas HTML y múltiples líneas
        jTable1.setRowHeight(jTable1.getRowHeight() * 2); // Ejemplo: Duplicar la altura de las filas

        // --- FIN DE LA CONFIGURACIÓN PERSONALIZADA DE JTABLE ---
        // Carga los datos en la tabla después de que jTable1 esté completamente configurado
        cargarTablaHistorialVentas();

        // Este MouseListener es para el doble clic, si lo quieres mantener
        jTable1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) { // Detectar doble clic
                    int selectedRow = jTable1.getSelectedRow();
                    if (selectedRow != -1) {
                        // Obtener el ID de la venta. Es importante obtenerlo del modelo, no de la vista,
                        // si la tabla puede ser ordenada (jTable1.convertRowIndexToModel(selectedRow))
                        int modelRow = jTable1.convertRowIndexToModel(selectedRow);
                        int idVentaSeleccionada = (int) jTable1.getModel().getValueAt(modelRow, 1);

                        Venta ventaSeleccionada = null;
                        for (Venta venta : historialVentas.obtenerTodasLasVentas()) {
                            if (venta.getIdVenta() == idVentaSeleccionada) {
                                ventaSeleccionada = venta;
                                break;
                            }
                        }

                        // Si no tienes frmDetalleVenta, puedes mostrar un JOptionPane.showMessageDialog aquí
                        if (ventaSeleccionada != null) {
                            JOptionPane.showMessageDialog(frmHistorialVentas.this,
                                    "Detalles de la Venta:\n"
                                    + "ID Venta: " + ventaSeleccionada.getIdVenta() + "\n"
                                    + "Fecha: " + ventaSeleccionada.getFechaCompraFormateada() + "\n"
                                    + "Cliente: " + ventaSeleccionada.getNombreCliente() + "\n"
                                    + "Productos:\n" + ventaSeleccionada.getProductosVendidosAsString().replace("<html>", "").replace("</html>", "").replace("<br>", "\n") + "\n"
                                    + "Total: $" + String.format("%,.2f", ventaSeleccionada.getTotalVenta()),
                                    "Detalle de Venta", JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                }
            }
        });
    }

    private void cargarTablaHistorialVentas() {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0);

        for (Venta venta : historialVentas.obtenerTodasLasVentas()) {
            model.addRow(new Object[]{
                venta.getFechaCompraFormateada(),
                venta.getIdVenta(),
                venta.getNombreCliente(),
                venta.getProductosVendidosAsString(),
                String.format("%,.2f", venta.getTotalVenta())
            });
        }
    }

    @SuppressWarnings("unchecked")

    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PanelConTodo = new javax.swing.JPanel();
        PanelCentral = new javax.swing.JPanel();
        btnVolverAlPanel = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        TopPanelIcons = new javax.swing.JPanel();
        WestPanel = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        EastPanel = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(700, 600));

        PanelConTodo.setMinimumSize(new java.awt.Dimension(700, 600));
        PanelConTodo.setPreferredSize(new java.awt.Dimension(700, 700));
        PanelConTodo.setLayout(new java.awt.BorderLayout());

        PanelCentral.setBackground(new java.awt.Color(255, 255, 255));

        btnVolverAlPanel.setBackground(new java.awt.Color(255, 255, 255));
        btnVolverAlPanel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnVolverAlPanel.setText("Volver al panel de administrador");
        btnVolverAlPanel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverAlPanelActionPerformed(evt);
            }
        });

        jTable1.setBackground(new java.awt.Color(255, 255, 255));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Fecha de compra", "ID de venta", "Cliente", "Productos vendidos", "Total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout PanelCentralLayout = new javax.swing.GroupLayout(PanelCentral);
        PanelCentral.setLayout(PanelCentralLayout);
        PanelCentralLayout.setHorizontalGroup(
            PanelCentralLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelCentralLayout.createSequentialGroup()
                .addGroup(PanelCentralLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelCentralLayout.createSequentialGroup()
                        .addGap(123, 123, 123)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(PanelCentralLayout.createSequentialGroup()
                        .addGap(234, 234, 234)
                        .addComponent(btnVolverAlPanel)))
                .addGap(125, 125, 125))
        );
        PanelCentralLayout.setVerticalGroup(
            PanelCentralLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelCentralLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnVolverAlPanel)
                .addGap(0, 66, Short.MAX_VALUE))
        );

        PanelConTodo.add(PanelCentral, java.awt.BorderLayout.CENTER);

        TopPanelIcons.setBackground(new java.awt.Color(255, 255, 255));
        TopPanelIcons.setPreferredSize(new java.awt.Dimension(800, 60));
        TopPanelIcons.setLayout(new java.awt.GridLayout(1, 2));

        WestPanel.setBackground(new java.awt.Color(255, 255, 255));
        WestPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/Icons/ICON_Historial_Ventas.jpg"))); // NOI18N
        WestPanel.add(jLabel2);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("Historial de ventas");
        WestPanel.add(jLabel1);

        TopPanelIcons.add(WestPanel);

        EastPanel.setBackground(new java.awt.Color(255, 255, 255));
        java.awt.FlowLayout flowLayout1 = new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT);
        flowLayout1.setAlignOnBaseline(true);
        EastPanel.setLayout(flowLayout1);
        TopPanelIcons.add(EastPanel);

        PanelConTodo.add(TopPanelIcons, java.awt.BorderLayout.NORTH);

        getContentPane().add(PanelConTodo, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVolverAlPanelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverAlPanelActionPerformed

        new frmAdmin().setVisible(true); // Abre el formulario de administrador
        this.dispose(); // Cierra el formulario actual
    }//GEN-LAST:event_btnVolverAlPanelActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmHistorialVentas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel EastPanel;
    private javax.swing.JPanel PanelCentral;
    private javax.swing.JPanel PanelConTodo;
    private javax.swing.JPanel TopPanelIcons;
    private javax.swing.JPanel WestPanel;
    private javax.swing.JButton btnVolverAlPanel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables

}
