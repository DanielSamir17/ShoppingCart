package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import modelo.Carrito;
import modelo.Producto;
import modelo.Sesion;
import controlador.HistorialVentas;
import java.util.List;
// Importa frmCatalogo y frmListaDeseos si son necesarios

public class frmListaProductos extends javax.swing.JFrame {

    private Carrito carrito;
    // Ya no necesitamos un mapa local 'cantidadesEnCarrito' si Carrito maneja las cantidades
    // private Map<Producto, Integer> cantidadesEnCarrito; 
    private HistorialVentas historialVentas;

    public frmListaProductos() {
        initComponents();
        this.setLocationRelativeTo(null);

        // El carrito del usuario activo ya maneja las cantidades
        carrito = Sesion.usuarioActivo.getCarrito();
        historialVentas = new HistorialVentas();

        cargarItemsCarrito();
    }

private void cargarItemsCarrito() {
    jpanelProductos.removeAll();

    List<Producto> productos = controlador.GestorProductos.cargarProductosDesdeArchivo();

    if (productos.isEmpty()) {
        JLabel emptyLabel = new JLabel("No hay productos registrados.");
        emptyLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        emptyLabel.setHorizontalAlignment(SwingConstants.CENTER);
        jpanelProductos.add(emptyLabel);
    } else {
        int index = 1;
        for (Producto producto : productos) {
            JPanel panelItem = new JPanel(new BorderLayout(10, 0));
            panelItem.setBackground(Color.WHITE);
            panelItem.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.LIGHT_GRAY));
            panelItem.setPreferredSize(new Dimension(760, 110));

            // Imagen
            JLabel lblImagen;
            try {
                lblImagen = new JLabel(new ImageIcon(
                    new ImageIcon(getClass().getResource(producto.getRutaImagen()))
                            .getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH)
                ));
            } catch (Exception e) {
                lblImagen = new JLabel("[Imagen]");
            }

            JPanel panelImagen = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
            panelImagen.setBackground(Color.WHITE);
            panelImagen.setPreferredSize(new Dimension(100, 100));
            panelImagen.add(lblImagen);
            panelItem.add(panelImagen, BorderLayout.WEST);

            // Info del producto
            JPanel panelInfo = new JPanel();
            panelInfo.setBackground(Color.WHITE);
            panelInfo.setLayout(new BoxLayout(panelInfo, BoxLayout.Y_AXIS));
            panelInfo.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

            JLabel lblNombre = new JLabel("<html><b>" + producto.getNombre() + "</b></html>");
            JLabel lblPrecio = new JLabel("COP " + String.format("%,.0f", producto.getPrecio()));
            JLabel lblId = new JLabel(String.format("N%03d", index));
            JLabel lblDisponibles = new JLabel("Disponibles: 10");

            panelInfo.add(lblNombre);
            panelInfo.add(lblPrecio);
            panelInfo.add(lblId);
            panelInfo.add(lblDisponibles);

            panelItem.add(panelInfo, BorderLayout.CENTER);

            jpanelProductos.add(panelItem);
            index++;
        }
    }

    jpanelProductos.revalidate();
    jpanelProductos.repaint();
}


    @SuppressWarnings("unchecked")

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpanelGeneral = new javax.swing.JPanel();
        TopPanelIcons = new javax.swing.JPanel();
        WestPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        EastPanel = new javax.swing.JPanel();
        btnLogout = new javax.swing.JToggleButton();
        JScrollPaneProductos = new javax.swing.JScrollPane();
        jpanelProductos = new javax.swing.JPanel();
        jpanelBotones = new javax.swing.JPanel();
        PanelTotal = new javax.swing.JPanel();
        btnVolverAdmin = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setMinimumSize(new java.awt.Dimension(620, 331));

        jpanelGeneral.setBackground(new java.awt.Color(255, 255, 255));
        jpanelGeneral.setPreferredSize(new java.awt.Dimension(800, 1000));
        jpanelGeneral.setLayout(new java.awt.BorderLayout());

        TopPanelIcons.setBackground(new java.awt.Color(255, 255, 255));
        TopPanelIcons.setPreferredSize(new java.awt.Dimension(800, 60));
        TopPanelIcons.setLayout(new java.awt.GridLayout(1, 2));

        WestPanel.setBackground(new java.awt.Color(255, 255, 255));
        WestPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/Icons/Carrito_Frame_60x60.png"))); // NOI18N
        WestPanel.add(jLabel1);

        TopPanelIcons.add(WestPanel);

        EastPanel.setBackground(new java.awt.Color(255, 255, 255));
        java.awt.FlowLayout flowLayout1 = new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT);
        flowLayout1.setAlignOnBaseline(true);
        EastPanel.setLayout(flowLayout1);

        btnLogout.setBackground(new java.awt.Color(255, 255, 255));
        btnLogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/Icons/Logout_Clear.png"))); // NOI18N
        btnLogout.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        btnLogout.setPreferredSize(new java.awt.Dimension(38, 38));
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });
        EastPanel.add(btnLogout);

        TopPanelIcons.add(EastPanel);

        jpanelGeneral.add(TopPanelIcons, java.awt.BorderLayout.NORTH);

        JScrollPaneProductos.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        JScrollPaneProductos.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        JScrollPaneProductos.setPreferredSize(new java.awt.Dimension(800, 1000));

        jpanelProductos.setBackground(new java.awt.Color(255, 255, 255));
        jpanelProductos.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));
        jpanelProductos.setAutoscrolls(true);
        jpanelProductos.setPreferredSize(new java.awt.Dimension(800, 800));
        jpanelProductos.setLayout(new javax.swing.BoxLayout(jpanelProductos, javax.swing.BoxLayout.Y_AXIS));
        JScrollPaneProductos.setViewportView(jpanelProductos);

        jpanelGeneral.add(JScrollPaneProductos, java.awt.BorderLayout.CENTER);

        jpanelBotones.setBackground(new java.awt.Color(255, 255, 255));
        jpanelBotones.setLayout(new java.awt.BorderLayout());

        PanelTotal.setBackground(new java.awt.Color(255, 255, 255));
        PanelTotal.setLayout(new java.awt.GridLayout(2, 0));
        jpanelBotones.add(PanelTotal, java.awt.BorderLayout.LINE_START);

        btnVolverAdmin.setBackground(new java.awt.Color(255, 255, 255));
        btnVolverAdmin.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVolverAdmin.setText("Volver al panel de Administrador");
        btnVolverAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverAdminActionPerformed(evt);
            }
        });
        jpanelBotones.add(btnVolverAdmin, java.awt.BorderLayout.CENTER);

        btnModificar.setBackground(new java.awt.Color(255, 255, 255));
        btnModificar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnModificar.setText("Modificar un producto");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });
        jpanelBotones.add(btnModificar, java.awt.BorderLayout.PAGE_START);

        jpanelGeneral.add(jpanelBotones, java.awt.BorderLayout.SOUTH);

        getContentPane().add(jpanelGeneral, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
        frmLogin login = new frmLogin();
        login.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnLogoutActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        // TODO add your handling code here:
    new frmModificarProducto().setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnVolverAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverAdminActionPerformed
         new frmAdmin().setVisible(true);
        dispose(); // Cierra el formulario actual
    }//GEN-LAST:event_btnVolverAdminActionPerformed

    /**
     * @param args the command line arguments
     */
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmListaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmListaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmListaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmListaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                if (modelo.Sesion.usuarioActivo == null) {
                    // Crea un usuario de prueba con ID 1 y rol "Cliente"
                    modelo.Sesion.usuarioActivo = new modelo.Usuario(1, "testuser", "password");
                }
                new frmListaProductos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel EastPanel;
    private javax.swing.JScrollPane JScrollPaneProductos;
    private javax.swing.JPanel PanelTotal;
    private javax.swing.JPanel TopPanelIcons;
    private javax.swing.JPanel WestPanel;
    private javax.swing.JToggleButton btnLogout;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnVolverAdmin;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jpanelBotones;
    private javax.swing.JPanel jpanelGeneral;
    private javax.swing.JPanel jpanelProductos;
    // End of variables declaration//GEN-END:variables
}
