package vista;

import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import modelo.Carrito; // Importa la clase Carrito
import modelo.ListaDeseos;
import modelo.Producto; // Importa la clase Producto
import modelo.Sesion;

public class frmCatalogo extends javax.swing.JFrame {

    Carrito carrito = Sesion.usuarioActivo.carrito;         // ✅ personalizado
    ListaDeseos listadeseos = Sesion.usuarioActivo.listaDeseos;

    private void cargarImagenesCatalogo() {
        setLayout(null);

// Teclado
        ImageIcon iconoTeclado = new ImageIcon(getClass().getResource("/Resources/Icons/teclado.png"));
        Image imgTeclado = iconoTeclado.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
        jLabelTeclado.setIcon(new ImageIcon(imgTeclado));
        jLabelTeclado.setBounds(50, 50, 150, 150);

// Mouse
        ImageIcon iconoMouse = new ImageIcon(getClass().getResource("/Resources/Icons/Mouse.png"));
        Image imgMouse = iconoMouse.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
        jLabelMouse.setIcon(new ImageIcon(imgMouse));
        jLabelMouse.setBounds(300, 50, 150, 150);

// Monitor
        ImageIcon iconoMonitor = new ImageIcon(getClass().getResource("/Resources/Icons/Monitor_Gamer.png"));
        Image imgMonitor = iconoMonitor.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
        jLabelMonitor.setIcon(new ImageIcon(imgMonitor));
        jLabelMonitor.setBounds(50, 250, 150, 150);

// Mando
        ImageIcon iconoMando = new ImageIcon(getClass().getResource("/Resources/Icons/Mando_Inalambrico.png"));
        Image imgMando = iconoMando.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
        jLabelMando.setIcon(new ImageIcon(imgMando));
        jLabelMando.setBounds(300, 250, 150, 150);

// Diademas
        ImageIcon iconoDiademas = new ImageIcon(getClass().getResource("/Resources/Icons/Diademas_Gamer.png"));
        Image imgDiademas = iconoDiademas.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
        jLabelDiademas.setIcon(new ImageIcon(imgDiademas));
        jLabelDiademas.setBounds(50, 450, 150, 150);

// MousePad
        ImageIcon iconoMousePad = new ImageIcon(getClass().getResource("/Resources/Icons/Mouse_Pad_Java_Commands.png"));
        Image imgMousePad = iconoMousePad.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
        jLabelMousePad.setIcon(new ImageIcon(imgMousePad));
        jLabelMousePad.setBounds(300, 450, 150, 150);

    }

    public frmCatalogo() {
        initComponents();
        cargarImagenesCatalogo(); // ← Esto prepara el panel con los productos  
        this.setLocationRelativeTo(null);
        lblBienvenida.setText("Bienvenido, " + Sesion.usuarioActivo.user + "!");

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelTop = new javax.swing.JPanel();
        panelWest = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        panelEast = new javax.swing.JPanel();
        btnCart6 = new javax.swing.JToggleButton();
        btnWishlist = new javax.swing.JToggleButton();
        btnLogout = new javax.swing.JToggleButton();
        lblBienvenida = new javax.swing.JLabel();
        panelContenedor = new javax.swing.JPanel();
        scrollCatalogo = new javax.swing.JScrollPane();
        panelCatalogo = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabelMonitor = new javax.swing.JLabel();
        jlabelMonitor = new javax.swing.JLabel();
        jlabelPrecioMonitor = new javax.swing.JLabel();
        btnCarritoMonitor = new javax.swing.JButton();
        btnWishMonitor = new javax.swing.JToggleButton();
        jPanel3 = new javax.swing.JPanel();
        jLabelMousePad = new javax.swing.JLabel();
        jlabelMousepad = new javax.swing.JLabel();
        jlabelPrecioMousepad = new javax.swing.JLabel();
        btnCarritoMousepad = new javax.swing.JButton();
        btnWishMousepad = new javax.swing.JToggleButton();
        jPanel1 = new javax.swing.JPanel();
        jLabelTeclado = new javax.swing.JLabel();
        jlabelTeclado = new javax.swing.JLabel();
        jlabelPrecioTeclado = new javax.swing.JLabel();
        btnCarritoTeclado = new javax.swing.JButton();
        btnWishTeclado = new javax.swing.JToggleButton();
        jPanel5 = new javax.swing.JPanel();
        jLabelDiademas = new javax.swing.JLabel();
        jlabelDiademas = new javax.swing.JLabel();
        jlabelPrecioDiademas = new javax.swing.JLabel();
        btnCarritoDiademas = new javax.swing.JButton();
        btnWishDiademas = new javax.swing.JToggleButton();
        jPanel2 = new javax.swing.JPanel();
        jLabelMouse = new javax.swing.JLabel();
        jlabelMouse = new javax.swing.JLabel();
        jlabelPrecioMouse = new javax.swing.JLabel();
        btnCarritoMouse = new javax.swing.JButton();
        btnWishMouse = new javax.swing.JToggleButton();
        jPanel6 = new javax.swing.JPanel();
        jLabelMando = new javax.swing.JLabel();
        jlabelMando = new javax.swing.JLabel();
        jlabelPrecioMando = new javax.swing.JLabel();
        btnCarritoMando = new javax.swing.JButton();
        btnWishMando = new javax.swing.JToggleButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        panelTop.setBackground(new java.awt.Color(255, 255, 255));
        panelTop.setLayout(new java.awt.BorderLayout());

        panelWest.setBackground(new java.awt.Color(255, 255, 255));
        panelWest.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/Icons/Icono_Catalogo.jpg"))); // NOI18N
        panelWest.add(jLabel13);

        panelTop.add(panelWest, java.awt.BorderLayout.LINE_START);

        panelEast.setBackground(new java.awt.Color(255, 255, 255));

        btnCart6.setBackground(new java.awt.Color(255, 255, 255));
        btnCart6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/Icons/Wishlist_Clear.png"))); // NOI18N
        btnCart6.setPreferredSize(new java.awt.Dimension(38, 38));
        btnCart6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCart6ActionPerformed(evt);
            }
        });
        panelEast.add(btnCart6);

        btnWishlist.setBackground(new java.awt.Color(255, 255, 255));
        btnWishlist.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/Icons/Carrito_Clear.png"))); // NOI18N
        btnWishlist.setToolTipText("");
        btnWishlist.setPreferredSize(new java.awt.Dimension(38, 38));
        btnWishlist.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnWishlistActionPerformed(evt);
            }
        });
        panelEast.add(btnWishlist);

        btnLogout.setBackground(new java.awt.Color(255, 255, 255));
        btnLogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/Icons/Logout_Clear.png"))); // NOI18N
        btnLogout.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        btnLogout.setPreferredSize(new java.awt.Dimension(38, 38));
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });
        panelEast.add(btnLogout);

        panelTop.add(panelEast, java.awt.BorderLayout.LINE_END);

        lblBienvenida.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblBienvenida.setText("Bienvenido XXXXX ! ");
        panelTop.add(lblBienvenida, java.awt.BorderLayout.CENTER);

        getContentPane().add(panelTop, java.awt.BorderLayout.PAGE_START);

        panelContenedor.setBackground(new java.awt.Color(255, 255, 255));
        panelContenedor.setLayout(new javax.swing.BoxLayout(panelContenedor, javax.swing.BoxLayout.Y_AXIS));

        scrollCatalogo.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        scrollCatalogo.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        panelCatalogo.setBackground(new java.awt.Color(255, 255, 255));
        panelCatalogo.setBorder(javax.swing.BorderFactory.createEmptyBorder(20, 40, 20, 40));
        panelCatalogo.setPreferredSize(new java.awt.Dimension(700, 800));
        panelCatalogo.setVerifyInputWhenFocusTarget(false);
        panelCatalogo.setLayout(new java.awt.GridLayout(0, 3));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createEmptyBorder(20, 1, 1, 1));
        jPanel4.setPreferredSize(new java.awt.Dimension(200, 250));
        jPanel4.setVerifyInputWhenFocusTarget(false);
        jPanel4.setLayout(new javax.swing.BoxLayout(jPanel4, javax.swing.BoxLayout.Y_AXIS));
        jPanel4.add(jLabelMonitor);

        jlabelMonitor.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlabelMonitor.setText("Monitor Gamer Curvado");
        jPanel4.add(jlabelMonitor);

        jlabelPrecioMonitor.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlabelPrecioMonitor.setText("750.000");
        jPanel4.add(jlabelPrecioMonitor);

        btnCarritoMonitor.setBackground(new java.awt.Color(255, 255, 255));
        btnCarritoMonitor.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCarritoMonitor.setText("Agregar al Carrito");
        btnCarritoMonitor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarritoMonitorActionPerformed(evt);
            }
        });
        jPanel4.add(btnCarritoMonitor);

        btnWishMonitor.setBackground(new java.awt.Color(255, 255, 255));
        btnWishMonitor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/Icons/Wishlist_Clear.png"))); // NOI18N
        btnWishMonitor.setPreferredSize(new java.awt.Dimension(38, 38));
        btnWishMonitor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnWishMonitorActionPerformed(evt);
            }
        });
        jPanel4.add(btnWishMonitor);

        panelCatalogo.add(jPanel4);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createEmptyBorder(20, 1, 1, 1));
        jPanel3.setPreferredSize(new java.awt.Dimension(200, 250));
        jPanel3.setVerifyInputWhenFocusTarget(false);
        jPanel3.setLayout(new javax.swing.BoxLayout(jPanel3, javax.swing.BoxLayout.Y_AXIS));
        jPanel3.add(jLabelMousePad);

        jlabelMousepad.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlabelMousepad.setText("MousePad Java Commands");
        jPanel3.add(jlabelMousepad);

        jlabelPrecioMousepad.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlabelPrecioMousepad.setText("80.000");
        jPanel3.add(jlabelPrecioMousepad);

        btnCarritoMousepad.setBackground(new java.awt.Color(255, 255, 255));
        btnCarritoMousepad.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCarritoMousepad.setText("Agregar al Carrito");
        btnCarritoMousepad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarritoMousepadActionPerformed(evt);
            }
        });
        jPanel3.add(btnCarritoMousepad);

        btnWishMousepad.setBackground(new java.awt.Color(255, 255, 255));
        btnWishMousepad.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/Icons/Wishlist_Clear.png"))); // NOI18N
        btnWishMousepad.setPreferredSize(new java.awt.Dimension(38, 38));
        btnWishMousepad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnWishMousepadActionPerformed(evt);
            }
        });
        jPanel3.add(btnWishMousepad);

        panelCatalogo.add(jPanel3);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createEmptyBorder(20, 1, 1, 1));
        jPanel1.setPreferredSize(new java.awt.Dimension(200, 250));
        jPanel1.setVerifyInputWhenFocusTarget(false);
        jPanel1.setLayout(new javax.swing.BoxLayout(jPanel1, javax.swing.BoxLayout.Y_AXIS));
        jPanel1.add(jLabelTeclado);

        jlabelTeclado.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlabelTeclado.setText("Teclado Mecanico 60%");
        jPanel1.add(jlabelTeclado);

        jlabelPrecioTeclado.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlabelPrecioTeclado.setText("150.000");
        jPanel1.add(jlabelPrecioTeclado);

        btnCarritoTeclado.setBackground(new java.awt.Color(255, 255, 255));
        btnCarritoTeclado.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCarritoTeclado.setText("Agregar al Carrito");
        btnCarritoTeclado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarritoTecladoActionPerformed(evt);
            }
        });
        jPanel1.add(btnCarritoTeclado);

        btnWishTeclado.setBackground(new java.awt.Color(255, 255, 255));
        btnWishTeclado.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/Icons/Wishlist_Clear.png"))); // NOI18N
        btnWishTeclado.setPreferredSize(new java.awt.Dimension(38, 38));
        btnWishTeclado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnWishTecladoActionPerformed(evt);
            }
        });
        jPanel1.add(btnWishTeclado);

        panelCatalogo.add(jPanel1);

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setPreferredSize(new java.awt.Dimension(200, 250));
        jPanel5.setVerifyInputWhenFocusTarget(false);
        jPanel5.setLayout(new javax.swing.BoxLayout(jPanel5, javax.swing.BoxLayout.Y_AXIS));
        jPanel5.add(jLabelDiademas);

        jlabelDiademas.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlabelDiademas.setText("Diademas Gamer");
        jPanel5.add(jlabelDiademas);

        jlabelPrecioDiademas.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlabelPrecioDiademas.setText("80.000");
        jPanel5.add(jlabelPrecioDiademas);

        btnCarritoDiademas.setBackground(new java.awt.Color(255, 255, 255));
        btnCarritoDiademas.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCarritoDiademas.setText("Agregar al Carrito");
        btnCarritoDiademas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarritoDiademasActionPerformed(evt);
            }
        });
        jPanel5.add(btnCarritoDiademas);

        btnWishDiademas.setBackground(new java.awt.Color(255, 255, 255));
        btnWishDiademas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/Icons/Wishlist_Clear.png"))); // NOI18N
        btnWishDiademas.setPreferredSize(new java.awt.Dimension(38, 38));
        btnWishDiademas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnWishDiademasActionPerformed(evt);
            }
        });
        jPanel5.add(btnWishDiademas);

        panelCatalogo.add(jPanel5);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setPreferredSize(new java.awt.Dimension(200, 250));
        jPanel2.setVerifyInputWhenFocusTarget(false);
        jPanel2.setLayout(new javax.swing.BoxLayout(jPanel2, javax.swing.BoxLayout.Y_AXIS));
        jPanel2.add(jLabelMouse);

        jlabelMouse.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlabelMouse.setText("Mouse Gamer RGB");
        jPanel2.add(jlabelMouse);

        jlabelPrecioMouse.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlabelPrecioMouse.setText("70.000");
        jPanel2.add(jlabelPrecioMouse);

        btnCarritoMouse.setBackground(new java.awt.Color(255, 255, 255));
        btnCarritoMouse.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCarritoMouse.setText("Agregar al Carrito");
        btnCarritoMouse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarritoMouseActionPerformed(evt);
            }
        });
        jPanel2.add(btnCarritoMouse);

        btnWishMouse.setBackground(new java.awt.Color(255, 255, 255));
        btnWishMouse.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/Icons/Wishlist_Clear.png"))); // NOI18N
        btnWishMouse.setPreferredSize(new java.awt.Dimension(38, 38));
        btnWishMouse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnWishMouseActionPerformed(evt);
            }
        });
        jPanel2.add(btnWishMouse);

        panelCatalogo.add(jPanel2);

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setPreferredSize(new java.awt.Dimension(200, 250));
        jPanel6.setVerifyInputWhenFocusTarget(false);
        jPanel6.setLayout(new javax.swing.BoxLayout(jPanel6, javax.swing.BoxLayout.Y_AXIS));
        jPanel6.add(jLabelMando);

        jlabelMando.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlabelMando.setText("Mando Inalambrico RGB");
        jPanel6.add(jlabelMando);

        jlabelPrecioMando.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlabelPrecioMando.setText("80.000");
        jPanel6.add(jlabelPrecioMando);

        btnCarritoMando.setBackground(new java.awt.Color(255, 255, 255));
        btnCarritoMando.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCarritoMando.setText("Agregar al Carrito");
        btnCarritoMando.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarritoMandoActionPerformed(evt);
            }
        });
        jPanel6.add(btnCarritoMando);

        btnWishMando.setBackground(new java.awt.Color(255, 255, 255));
        btnWishMando.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/Icons/Wishlist_Clear.png"))); // NOI18N
        btnWishMando.setPreferredSize(new java.awt.Dimension(38, 38));
        btnWishMando.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnWishMandoActionPerformed(evt);
            }
        });
        jPanel6.add(btnWishMando);

        panelCatalogo.add(jPanel6);

        scrollCatalogo.setViewportView(panelCatalogo);

        panelContenedor.add(scrollCatalogo);

        getContentPane().add(panelContenedor, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCarritoMonitorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarritoMonitorActionPerformed
        Producto monitor = new Producto("Monitor Gamer Curvado", 750000.0, "/Resources/Icons/Monitor_Gamer.png");
        Sesion.usuarioActivo.carrito.agregarProducto(monitor);
        Sesion.usuarioActivo.guardarCarritoEnArchivo();

        JOptionPane.showMessageDialog(this, "Producto agregado al carrito correctamente.", "Confirmación", JOptionPane.PLAIN_MESSAGE);
    }//GEN-LAST:event_btnCarritoMonitorActionPerformed

    private void btnCarritoMousepadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarritoMousepadActionPerformed
        Producto mousepad = new Producto("MousePad Java Commands", 80000.0, "/Resources/Icons/Mouse_Pad_Java_Commands.png");
        Sesion.usuarioActivo.carrito.agregarProducto(mousepad);
        Sesion.usuarioActivo.guardarCarritoEnArchivo();

        JOptionPane.showMessageDialog(this, "Producto agregado al carrito correctamente.", "Confirmación", JOptionPane.PLAIN_MESSAGE);


    }//GEN-LAST:event_btnCarritoMousepadActionPerformed

    private void btnCarritoDiademasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarritoDiademasActionPerformed
        Producto diademas = new Producto("Diademas Gamer", 80000.0, "/Resources/Icons/Diademas_Gamer.png");
        Sesion.usuarioActivo.carrito.agregarProducto(diademas);
        Sesion.usuarioActivo.guardarCarritoEnArchivo();

        JOptionPane.showMessageDialog(this, "Producto agregado al carrito correctamente.", "Confirmación", JOptionPane.PLAIN_MESSAGE);

    }//GEN-LAST:event_btnCarritoDiademasActionPerformed

    private void btnCarritoMouseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarritoMouseActionPerformed
        Producto mouse = new Producto("Mouse Gamer RGB", 70000.0, "/Resources/Icons/Mouse.png");
        Sesion.usuarioActivo.carrito.agregarProducto(mouse);
        Sesion.usuarioActivo.guardarCarritoEnArchivo();

        JOptionPane.showMessageDialog(this, "Producto agregado al carrito correctamente.", "Confirmación", JOptionPane.PLAIN_MESSAGE);


    }//GEN-LAST:event_btnCarritoMouseActionPerformed

    private void btnCarritoMandoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarritoMandoActionPerformed
        Producto mando = new Producto("Mando Inalambrico RGB", 80000.0, "/Resources/Icons/Mando_Inalambrico.png");
        Sesion.usuarioActivo.carrito.agregarProducto(mando);
        Sesion.usuarioActivo.guardarCarritoEnArchivo();

        JOptionPane.showMessageDialog(this, "Producto agregado al carrito correctamente.", "Confirmación", JOptionPane.PLAIN_MESSAGE);

    }//GEN-LAST:event_btnCarritoMandoActionPerformed

    private void btnCarritoTecladoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarritoTecladoActionPerformed
        Producto teclado = new Producto("Teclado Mecanico 60%", 150000.0, "/Resources/Icons/teclado.png");
        Sesion.usuarioActivo.carrito.agregarProducto(teclado);
        Sesion.usuarioActivo.guardarCarritoEnArchivo(); // ✅ GUARDA EN ARCHIVO

        JOptionPane.showMessageDialog(this, "Producto agregado al carrito correctamente.", "Confirmación", JOptionPane.PLAIN_MESSAGE);


    }//GEN-LAST:event_btnCarritoTecladoActionPerformed

    private void btnWishMousepadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnWishMousepadActionPerformed
       Producto mousepad = new Producto("MousePad Java Commands", 80000.0, "/Resources/Icons/Mouse_Pad_Java_Commands.png");
    Sesion.usuarioActivo.listaDeseos.agregarProducto(mousepad);
    Sesion.usuarioActivo.guardarListaDeseosEnArchivo();

    JOptionPane.showMessageDialog(this, "Producto agregado a la lista de deseos correctamente.", "Confirmación", JOptionPane.PLAIN_MESSAGE);

    }//GEN-LAST:event_btnWishMousepadActionPerformed

    private void btnWishTecladoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnWishTecladoActionPerformed

        Producto teclado = new Producto("Teclado Mecanico 60%", 150000.0, "/Resources/Icons/teclado.png");
    Sesion.usuarioActivo.listaDeseos.agregarProducto(teclado);
    Sesion.usuarioActivo.guardarListaDeseosEnArchivo(); // ❤️ GUARDA .TXT

    JOptionPane.showMessageDialog(this, "Producto agregado a la lista de deseos correctamente.", "Confirmación", JOptionPane.PLAIN_MESSAGE);


    }//GEN-LAST:event_btnWishTecladoActionPerformed

    private void btnWishDiademasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnWishDiademasActionPerformed

        Producto diademas = new Producto("Diademas Gamer", 80000.0, "/Resources/Icons/Diademas_Gamer.png");
    Sesion.usuarioActivo.listaDeseos.agregarProducto(diademas);
    Sesion.usuarioActivo.guardarListaDeseosEnArchivo();

    JOptionPane.showMessageDialog(this, "Producto agregado a la lista de deseos correctamente.", "Confirmación", JOptionPane.PLAIN_MESSAGE);

    }//GEN-LAST:event_btnWishDiademasActionPerformed

    private void btnWishMouseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnWishMouseActionPerformed

       Producto mouse = new Producto("Mouse Gamer RGB", 70000.0, "/Resources/Icons/Mouse.png");
    Sesion.usuarioActivo.listaDeseos.agregarProducto(mouse);
    Sesion.usuarioActivo.guardarListaDeseosEnArchivo();

    JOptionPane.showMessageDialog(this, "Producto agregado a la lista de deseos correctamente.", "Confirmación", JOptionPane.PLAIN_MESSAGE);


    }//GEN-LAST:event_btnWishMouseActionPerformed

    private void btnWishMandoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnWishMandoActionPerformed

        Producto mando = new Producto("Mando Inalambrico RGB", 80000.0, "/Resources/Icons/Mando_Inalambrico.png");
    Sesion.usuarioActivo.listaDeseos.agregarProducto(mando);
    Sesion.usuarioActivo.guardarListaDeseosEnArchivo();

    JOptionPane.showMessageDialog(this, "Producto agregado a la lista de deseos correctamente.", "Confirmación", JOptionPane.PLAIN_MESSAGE);

    }//GEN-LAST:event_btnWishMandoActionPerformed

    private void btnCart6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCart6ActionPerformed

        // Abre el formulario del carrito
        frmWishList listadeseosFrame = new frmWishList();
        listadeseosFrame.setVisible(true);
        // Opcional: puedes cerrar esta ventana si quieres que el carrito sea la única visible
        this.dispose();
    }//GEN-LAST:event_btnCart6ActionPerformed

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
        frmLogin login = new frmLogin(); // crea la ventana de login
        login.setVisible(true);          // la muestra
        this.dispose();
    }//GEN-LAST:event_btnLogoutActionPerformed

    private void btnWishlistActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnWishlistActionPerformed
        // TODO add your handling code here:
        // Abre el formulario del carrito
        frmCarrito carritoFrame = new frmCarrito();
        carritoFrame.setVisible(true);
        // Opcional: puedes cerrar esta ventana si quieres que el carrito sea la única visible
        this.dispose();
    }//GEN-LAST:event_btnWishlistActionPerformed

    private void btnWishMonitorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnWishMonitorActionPerformed

       Producto monitor = new Producto("Monitor Gamer Curvado", 750000.0, "/Resources/Icons/Monitor_Gamer.png");
    Sesion.usuarioActivo.listaDeseos.agregarProducto(monitor);
    Sesion.usuarioActivo.guardarListaDeseosEnArchivo();

    JOptionPane.showMessageDialog(this, "Producto agregado a la lista de deseos correctamente.", "Confirmación", JOptionPane.PLAIN_MESSAGE);


    }//GEN-LAST:event_btnWishMonitorActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmCatalogo.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmCatalogo.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmCatalogo.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmCatalogo.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmCatalogo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCarritoDiademas;
    private javax.swing.JButton btnCarritoMando;
    private javax.swing.JButton btnCarritoMonitor;
    private javax.swing.JButton btnCarritoMouse;
    private javax.swing.JButton btnCarritoMousepad;
    private javax.swing.JButton btnCarritoTeclado;
    private javax.swing.JToggleButton btnCart6;
    private javax.swing.JToggleButton btnLogout;
    private javax.swing.JToggleButton btnWishDiademas;
    private javax.swing.JToggleButton btnWishMando;
    private javax.swing.JToggleButton btnWishMonitor;
    private javax.swing.JToggleButton btnWishMouse;
    private javax.swing.JToggleButton btnWishMousepad;
    private javax.swing.JToggleButton btnWishTeclado;
    private javax.swing.JToggleButton btnWishlist;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabelDiademas;
    private javax.swing.JLabel jLabelMando;
    private javax.swing.JLabel jLabelMonitor;
    private javax.swing.JLabel jLabelMouse;
    private javax.swing.JLabel jLabelMousePad;
    private javax.swing.JLabel jLabelTeclado;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    public javax.swing.JLabel jlabelDiademas;
    public javax.swing.JLabel jlabelMando;
    public javax.swing.JLabel jlabelMonitor;
    public javax.swing.JLabel jlabelMouse;
    public javax.swing.JLabel jlabelMousepad;
    public javax.swing.JLabel jlabelPrecioDiademas;
    public javax.swing.JLabel jlabelPrecioMando;
    public javax.swing.JLabel jlabelPrecioMonitor;
    public javax.swing.JLabel jlabelPrecioMouse;
    public javax.swing.JLabel jlabelPrecioMousepad;
    public javax.swing.JLabel jlabelPrecioTeclado;
    public javax.swing.JLabel jlabelTeclado;
    private javax.swing.JLabel lblBienvenida;
    private javax.swing.JPanel panelCatalogo;
    private javax.swing.JPanel panelContenedor;
    private javax.swing.JPanel panelEast;
    private javax.swing.JPanel panelTop;
    private javax.swing.JPanel panelWest;
    private javax.swing.JScrollPane scrollCatalogo;
    // End of variables declaration//GEN-END:variables
}
