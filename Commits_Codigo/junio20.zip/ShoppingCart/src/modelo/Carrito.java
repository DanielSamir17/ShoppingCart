package modelo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Carrito {
    // Usamos un mapa para almacenar el Producto y su cantidad
    private Map<Producto, Integer> productosEnCarrito;

    public Carrito() {
        productosEnCarrito = new HashMap<>();
    }

    public void agregarProducto(Producto producto) {
        // Incrementa la cantidad si el producto ya está, o añade 1 si es nuevo
        productosEnCarrito.put(producto, productosEnCarrito.getOrDefault(producto, 0) + 1);
        System.out.println("Producto '" + producto.getNombre() + "' agregado al carrito. Cantidad: " + productosEnCarrito.get(producto));
    }
    
    // Método para agregar una cantidad específica de un producto
    public void agregarProducto(Producto producto, int cantidad) {
        if (cantidad > 0) {
            productosEnCarrito.put(producto, productosEnCarrito.getOrDefault(producto, 0) + cantidad);
            System.out.println("Se agregaron " + cantidad + " unidades de '" + producto.getNombre() + "' al carrito. Cantidad total: " + productosEnCarrito.get(producto));
        }
    }

    public void quitarProducto(Producto producto) {
        if (productosEnCarrito.containsKey(producto)) {
            int cantidadActual = productosEnCarrito.get(producto);
            if (cantidadActual > 1) {
                productosEnCarrito.put(producto, cantidadActual - 1);
                System.out.println("Se quitó una unidad de '" + producto.getNombre() + "'. Cantidad restante: " + productosEnCarrito.get(producto));
            } else {
                productosEnCarrito.remove(producto);
                System.out.println("Producto '" + producto.getNombre() + "' eliminado completamente del carrito.");
            }
        }
    }
    
    // Método para eliminar un producto completamente del carrito, sin importar la cantidad
    public void eliminarProductoCompletamente(Producto producto) {
        if (productosEnCarrito.remove(producto) != null) {
            System.out.println("Todas las unidades de '" + producto.getNombre() + "' han sido eliminadas del carrito.");
        }
    }

    // Devuelve un mapa inmutable para evitar modificaciones externas directas
    public Map<Producto, Integer> getProductosEnCarrito() {
        return new HashMap<>(productosEnCarrito);
    }
    
    // Devuelve una lista de productos "aplanada" si alguna parte del código aún lo necesita
    public List<Producto> getProductos() {
        List<Producto> listaPlana = new ArrayList<>();
        for (Map.Entry<Producto, Integer> entry : productosEnCarrito.entrySet()) {
            for (int i = 0; i < entry.getValue(); i++) {
                listaPlana.add(entry.getKey());
            }
        }
        return listaPlana;
    }

    public void limpiarCarrito() {
        productosEnCarrito.clear();
        System.out.println("Carrito limpiado.");
    }

    public double getTotal() {
        double total = 0;
        for (Map.Entry<Producto, Integer> entry : productosEnCarrito.entrySet()) {
            total += entry.getKey().getPrecio() * entry.getValue();
        }
        return total;
    }
    
    public boolean estaVacio() {
        return productosEnCarrito.isEmpty();
    }
}   
