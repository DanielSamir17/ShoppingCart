package controlador;

import modelo.Venta;
import modelo.Producto;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class HistorialVentas {
    private List<Venta> ventas;
    private int nextIdVenta;
    private static final String ARCHIVO_VENTAS = "src/ArchivoTexto/historial_ventas.txt";

    public HistorialVentas() {
        ventas = new ArrayList<>();
        nextIdVenta = 1;
        cargarHistorialDesdeArchivo();
    }

    public void agregarVenta(String nombreCliente, Map<Producto, Integer> productosVendidos, double totalVenta) {
        Venta nuevaVenta = new Venta(nextIdVenta++, nombreCliente, productosVendidos, totalVenta);
        ventas.add(nuevaVenta);
        guardarHistorialEnArchivo();
    }

    public List<Venta> obtenerTodasLasVentas() {
        return new ArrayList<>(ventas);
    }

    private void cargarHistorialDesdeArchivo() {
        ventas.clear();
        nextIdVenta = 1;

        File archivo = new File(ARCHIVO_VENTAS);
        if (!archivo.exists()) {
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(";");
                if (partes.length == 5) {
                    try {
                        int id = Integer.parseInt(partes[0]);
                        String fechaStr = partes[1];
                        String cliente = partes[2];
                        double total = Double.parseDouble(partes[3]);
                        String productosStr = partes[4];

                        Map<Producto, Integer> productosVendidos = new HashMap<>();
                        if (!productosStr.isEmpty()) {
                            String[] paresProductos = productosStr.split("\\|");
                            for (String par : paresProductos) {
                                String[] detallesProducto = par.split(",");
                                if (detallesProducto.length == 4) { // Ahora esperamos 4 detalles: nombre, precio, ruta, cantidad
                                    String nombreProd = detallesProducto[0];
                                    double precioProd = Double.parseDouble(detallesProducto[1]);
                                    String rutaImg = detallesProducto[2];
                                    int cantidadProd = Integer.parseInt(detallesProducto[3]);
                                    
                                    productosVendidos.put(new Producto(nombreProd, precioProd, rutaImg), cantidadProd);
                                }
                            }
                        }
                        
                        Venta ventaCargada = new Venta(id, fechaStr, cliente, productosVendidos, total);
                        ventas.add(ventaCargada);
                        
                        if (id >= nextIdVenta) {
                            nextIdVenta = id + 1;
                        }

                    } catch (NumberFormatException e) {
                        System.err.println("Error de formato numérico o producto inválido en línea: " + linea + " - " + e.getMessage());
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error al cargar el historial de ventas: " + e.getMessage());
        }
    }

    private void guardarHistorialEnArchivo() {
        File carpeta = new File("src/ArchivoTexto");
        if (!carpeta.exists()) {
            carpeta.mkdirs();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ARCHIVO_VENTAS))) {
            for (Venta venta : ventas) {
                StringBuilder productosStr = new StringBuilder();
                for (Map.Entry<Producto, Integer> entry : venta.getProductosVendidos().entrySet()) {
                    productosStr.append(entry.getKey().getNombre()).append(",")
                                .append(entry.getKey().getPrecio()).append(",")
                                .append(entry.getKey().getRutaImagen()).append(",")
                                .append(entry.getValue()).append("|"); // Guardamos la cantidad
                }
                if (productosStr.length() > 0) {
                    productosStr.setLength(productosStr.length() - 1);
                }

                writer.write(venta.getIdVenta() + ";" + 
                             venta.getFechaCompraFormateada() + ";" + 
                             venta.getNombreCliente() + ";" + 
                             venta.getTotalVenta() + ";" + 
                             productosStr.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error al guardar el historial de ventas: " + e.getMessage());
        }
    }
}
