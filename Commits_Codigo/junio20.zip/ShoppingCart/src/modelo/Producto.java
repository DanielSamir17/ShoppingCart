package modelo;

public class Producto {
    private String nombre;
    private double precio;
    private String rutaImagen;

    public Producto(String nombre, double precio, String rutaImagen) {
        this.nombre = nombre;
        this.precio = precio;
        this.rutaImagen = rutaImagen;
    }

    // Getters
    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public String getRutaImagen() {
        return rutaImagen;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Producto producto = (Producto) o;
        return Double.compare(producto.precio, precio) == 0 &&
               nombre.equals(producto.nombre) &&
               rutaImagen.equals(producto.rutaImagen);
    }

    @Override
    public int hashCode() {
        int result = nombre.hashCode();
        result = 31 * result + Double.hashCode(precio);
        result = 31 * result + rutaImagen.hashCode();
        return result;
    }
}