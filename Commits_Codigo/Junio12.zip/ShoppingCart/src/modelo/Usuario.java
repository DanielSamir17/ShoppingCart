package modelo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Usuario {
    public int id; // Nuevo campo para el ID del usuario
    public String user;
    public String contra;

    public Carrito carrito;
    public ListaDeseos listaDeseos;

    // Constructor que incluye el ID
    public Usuario(int id, String user, String contra) {
        this.id = id;
        this.user = user;
        this.contra = contra;
        this.carrito = new Carrito();
        this.listaDeseos = new ListaDeseos();
    }

    // Constructor original (opcional, para compatibilidad si lo necesitas)
    public Usuario(String user, String contra) {
        this(0, user, contra); // Por defecto, ID 0 si no se especifica
    }

    // Getters para el ID, user y contra (recomendado para acceder a los datos)
    public int getId() {
        return id;
    }

    public String getUser() {
        return user;
    }

    public String getContra() {
        return contra;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setContra(String contra) {
        this.contra = contra;
    }

    public void guardarCarritoEnArchivo() {
        try {
            File archivo = new File("src/ArchivoTexto/" + user + "_carrito.txt");
            BufferedWriter bw = new BufferedWriter(new FileWriter(archivo));
            for (Producto p : carrito.getProductos()) {
                bw.write(p.getNombre() + "," + p.getPrecio() + "," + p.getRutaImagen());
                bw.newLine();
            }
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void cargarCarritoDesdeArchivo() {
        carrito.limpiarCarrito(); // limpia antes de cargar
        File archivo = new File("src/ArchivoTexto/" + user + "_carrito.txt");
        if (!archivo.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 3) {
                    String nombre = partes[0];
                    double precio = Double.parseDouble(partes[1]);
                    String ruta = partes[2];
                    carrito.agregarProducto(new Producto(nombre, precio, ruta));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void guardarListaDeseosEnArchivo() {
        try {
            File archivo = new File("src/ArchivoTexto/" + user + "_listaDeseos.txt");
            BufferedWriter bw = new BufferedWriter(new FileWriter(archivo));
            for (Producto p : listaDeseos.getProductos()) {
                bw.write(p.getNombre() + "," + p.getPrecio() + "," + p.getRutaImagen());
                bw.newLine();
            }
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void cargarListaDeseosDesdeArchivo() {
        listaDeseos.limpiarListaDeseos(); // Limpia la lista antes de cargar
        File archivo = new File("src/ArchivoTexto/" + user + "_listaDeseos.txt");
        if (!archivo.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 3) {
                    String nombre = partes[0];
                    double precio = Double.parseDouble(partes[1]);
                    String ruta = partes[2];
                    listaDeseos.agregarProducto(new Producto(nombre, precio, ruta));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}