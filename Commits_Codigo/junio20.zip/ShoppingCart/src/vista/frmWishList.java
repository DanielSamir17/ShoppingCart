package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import modelo.Carrito;
import modelo.Producto;
import modelo.Sesion;
import controlador.HistorialVentas;
import static java.awt.Component.CENTER_ALIGNMENT;
import static java.awt.Component.LEFT_ALIGNMENT;
import modelo.ListaDeseos;
// Importa frmCatalogo y frmListaDeseos si son necesarios
// Importa frmAdmin si el usuario activo es un administrador y puede regresar a su panel

public class frmWishList extends javax.swing.JFrame {

    private ListaDeseos listadeseos; // Instancia del carrito (singleton)

    public frmWishList() {
        initComponents(); // Carga los componentes diseñados por NetBeans
        this.setLocationRelativeTo(null); // Centra la ventana

        // Inicializa la instancia del carrito
        listadeseos = Sesion.usuarioActivo.listaDeseos;

        // Configura el layout del panel que contendrá los productos dinámicamente
        // Esto NO debe ir en initComponents(), sino aquí en el constructor o en un método de setup.
        jpanelProductos.setLayout(new BoxLayout(jpanelProductos, BoxLayout.Y_AXIS));
        jpanelProductos.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Añade un borde para espacio
        jpanelProductos.setBackground(Color.WHITE); // Fondo blanco para el panel de productos

        cargarItemsListaDeseos(); // Llama al método para cargar los productos al inicio
    }

    /**
     * Carga y muestra los productos que están actualmente en el carrito. Este
     * método limpia el panel de productos y lo vuelve a construir con los
     * elementos actualizados del carrito.
     */
    private void cargarItemsListaDeseos() {
        jpanelProductos.removeAll(); // Limpia el panel antes de añadir nuevos items
        double total = 0;

        List<Producto> productosEnListaDeseos = listadeseos.getProductos();

        if (productosEnListaDeseos.isEmpty()) {
            JLabel emptyLabel = new JLabel("El carrito está vacío.");
            emptyLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
            emptyLabel.setHorizontalAlignment(SwingConstants.CENTER);
            emptyLabel.setAlignmentX(CENTER_ALIGNMENT); // Importante para BoxLayout
            jpanelProductos.add(emptyLabel);
        } else {
            for (Producto producto : productosEnListaDeseos) {
                JPanel panelItem = new JPanel();
                // Usamos BorderLayout para organizar la imagen a la izquierda y los detalles a la derecha
                panelItem.setLayout(new BorderLayout(10, 0)); // 10px de espacio horizontal
                panelItem.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.LIGHT_GRAY)); // Línea divisoria inferior
                panelItem.setBackground(Color.WHITE); // Fondo blanco para cada item
                panelItem.setPreferredSize(new Dimension(600, 80)); // Tamaño preferido para cada item
                panelItem.setMaximumSize(new Dimension(Short.MAX_VALUE, 80)); // Para que no crezca demasiado verticalmente

                // Panel para la imagen
                JPanel panelImagen = new JPanel();
                panelImagen.setBackground(Color.WHITE);
                panelImagen.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0)); // Sin espaciado extra
                panelImagen.setPreferredSize(new Dimension(80, 80)); // Tamaño fijo para la imagen
                panelImagen.setMinimumSize(new Dimension(80, 80));
                panelImagen.setMaximumSize(new Dimension(80, 80));

                ImageIcon icono = new ImageIcon(getClass().getResource(producto.getRutaImagen()));
                Image img = icono.getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH);
                JLabel lblImagen = new JLabel(new ImageIcon(img));
                lblImagen.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Padding alrededor de la imagen
                panelImagen.add(lblImagen);
                panelItem.add(panelImagen, BorderLayout.WEST);

                // Panel para los detalles (nombre y precio)
                JPanel panelDetalles = new JPanel();
                panelDetalles.setBackground(Color.WHITE);
                panelDetalles.setLayout(new BoxLayout(panelDetalles, BoxLayout.Y_AXIS));
                panelDetalles.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0)); // Padding vertical

                JLabel lblNombre = new JLabel("<html><b>" + producto.getNombre() + "</b></html>");
                lblNombre.setFont(new Font("Segoe UI", Font.BOLD, 14));
                lblNombre.setAlignmentX(LEFT_ALIGNMENT); // Alinea el texto a la izquierda
                panelDetalles.add(lblNombre);

                JLabel lblPrecio = new JLabel("$" + String.format("%,.2f", producto.getPrecio()));
                lblPrecio.setFont(new Font("Segoe UI", Font.PLAIN, 14));
                lblPrecio.setAlignmentX(LEFT_ALIGNMENT); // Alinea el texto a la izquierda
                panelDetalles.add(lblPrecio);

                panelItem.add(panelDetalles, BorderLayout.CENTER);

                // Panel para los botones de cantidad (simulados)
                JPanel panelCantidad = new JPanel();
                panelCantidad.setBackground(Color.WHITE);
                panelCantidad.setLayout(new FlowLayout(FlowLayout.RIGHT, 5, 5)); // Alinea a la derecha

                JLabel lblCantidad = new JLabel("1"); // Cantidad fija por ahora
                lblCantidad.setFont(new Font("Segoe UI", Font.PLAIN, 14));
                lblCantidad.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
                lblCantidad.setPreferredSize(new Dimension(30, 25));
                lblCantidad.setHorizontalAlignment(SwingConstants.CENTER);

                JButton btnMinus = new JButton("-");
                btnMinus.setPreferredSize(new Dimension(25, 25));
                btnMinus.setMargin(new java.awt.Insets(0, 0, 0, 0));
                btnMinus.setFont(new Font("Segoe UI", Font.BOLD, 10));

                JButton btnPlus = new JButton("+");
                btnPlus.setPreferredSize(new Dimension(25, 25));
                btnPlus.setMargin(new java.awt.Insets(0, 0, 0, 0));
                btnPlus.setFont(new Font("Segoe UI", Font.BOLD, 10));

                panelCantidad.add(btnMinus);
                panelCantidad.add(lblCantidad);
                panelCantidad.add(btnPlus);

                panelItem.add(panelCantidad, BorderLayout.EAST);

                jpanelProductos.add(panelItem); // Añade el panel del ítem al panel principal de productos
                total += producto.getPrecio();
            }
        }
    }
    @SuppressWarnings("unchecked")
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpanelGeneral = new javax.swing.JPanel();
        TopPanelIcons = new javax.swing.JPanel();
        WestPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        EastPanel = new javax.swing.JPanel();
        btnWishlist = new javax.swing.JToggleButton();
        btnLogout = new javax.swing.JToggleButton();
        JScrollPaneProductos = new javax.swing.JScrollPane();
        jpanelProductos = new javax.swing.JPanel();
        jpanelBotones = new javax.swing.JPanel();
        panelAcciones = new javax.swing.JPanel();
        btnEnviarAlCarrito = new javax.swing.JButton();
        btnVolverCatalogo = new javax.swing.JButton();
        btnLimpiarCarrito = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setMinimumSize(new java.awt.Dimension(620, 331));
        setPreferredSize(new java.awt.Dimension(700, 800));

        jpanelGeneral.setBackground(new java.awt.Color(255, 255, 255));
        jpanelGeneral.setPreferredSize(new java.awt.Dimension(800, 1000));
        jpanelGeneral.setLayout(new java.awt.BorderLayout());

        TopPanelIcons.setBackground(new java.awt.Color(255, 255, 255));
        TopPanelIcons.setPreferredSize(new java.awt.Dimension(800, 60));
        TopPanelIcons.setLayout(new java.awt.GridLayout(1, 2));

        WestPanel.setBackground(new java.awt.Color(255, 255, 255));
        WestPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/Icons/Icono_WIshlist.jpg"))); // NOI18N
        WestPanel.add(jLabel1);

        TopPanelIcons.add(WestPanel);

        EastPanel.setBackground(new java.awt.Color(255, 255, 255));
        EastPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnWishlist.setBackground(new java.awt.Color(255, 255, 255));
        btnWishlist.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/Icons/Carrito_Clear.png"))); // NOI18N
        btnWishlist.setToolTipText("");
        btnWishlist.setPreferredSize(new java.awt.Dimension(38, 38));
        btnWishlist.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnWishlistActionPerformed(evt);
            }
        });
        EastPanel.add(btnWishlist);

        btnLogout.setBackground(new java.awt.Color(255, 255, 255));
        btnLogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/Icons/Logout_Clear.png"))); // NOI18N
        btnLogout.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        btnLogout.setPreferredSize(new java.awt.Dimension(38, 38));
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });
        EastPanel.add(btnLogout);

        TopPanelIcons.add(EastPanel);

        jpanelGeneral.add(TopPanelIcons, java.awt.BorderLayout.NORTH);

        JScrollPaneProductos.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        JScrollPaneProductos.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        JScrollPaneProductos.setPreferredSize(new java.awt.Dimension(800, 1000));

        jpanelProductos.setBackground(new java.awt.Color(255, 255, 255));
        jpanelProductos.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));
        jpanelProductos.setAutoscrolls(true);
        jpanelProductos.setPreferredSize(new java.awt.Dimension(800, 800));
        jpanelProductos.setLayout(new javax.swing.BoxLayout(jpanelProductos, javax.swing.BoxLayout.Y_AXIS));
        JScrollPaneProductos.setViewportView(jpanelProductos);

        jpanelGeneral.add(JScrollPaneProductos, java.awt.BorderLayout.CENTER);

        jpanelBotones.setBackground(new java.awt.Color(255, 255, 255));
        jpanelBotones.setLayout(new java.awt.BorderLayout());

        panelAcciones.setBackground(new java.awt.Color(255, 255, 255));
        panelAcciones.setPreferredSize(new java.awt.Dimension(800, 70));

        btnEnviarAlCarrito.setBackground(new java.awt.Color(255, 255, 255));
        btnEnviarAlCarrito.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnEnviarAlCarrito.setText("Enviar al Carrito");
        btnEnviarAlCarrito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnviarAlCarritoActionPerformed(evt);
            }
        });
        panelAcciones.add(btnEnviarAlCarrito);

        btnVolverCatalogo.setBackground(new java.awt.Color(255, 255, 255));
        btnVolverCatalogo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVolverCatalogo.setText("Volver al catalogo");
        btnVolverCatalogo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverCatalogoActionPerformed(evt);
            }
        });
        panelAcciones.add(btnVolverCatalogo);

        btnLimpiarCarrito.setBackground(new java.awt.Color(255, 255, 255));
        btnLimpiarCarrito.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnLimpiarCarrito.setText("Limpiar Carrito");
        btnLimpiarCarrito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarCarritoActionPerformed(evt);
            }
        });
        panelAcciones.add(btnLimpiarCarrito);

        jpanelBotones.add(panelAcciones, java.awt.BorderLayout.LINE_END);

        jpanelGeneral.add(jpanelBotones, java.awt.BorderLayout.SOUTH);

        getContentPane().add(jpanelGeneral, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents
           

    private void btnLimpiarCarritoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarCarritoActionPerformed
         // TODO add your handling code here:
        listadeseos.limpiarListaDeseos();
        cargarItemsListaDeseos(); // Actualiza la vista del carrito para que muestre "Carrito vacío"
    }//GEN-LAST:event_btnLimpiarCarritoActionPerformed

    private void btnEnviarAlCarritoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnviarAlCarritoActionPerformed
        ListaDeseos listaDeseos = Sesion.usuarioActivo.listaDeseos;
        Carrito carrito = Sesion.usuarioActivo.carrito;

        for (Producto producto : listaDeseos.getProductos()) {
            carrito.agregarProducto(producto);
        }

        listaDeseos.limpiarListaDeseos(); // Opcional: borra después de transferir

        // ✅ GUARDA EN ARCHIVOS
        Sesion.usuarioActivo.guardarCarritoEnArchivo();
        Sesion.usuarioActivo.guardarListaDeseosEnArchivo();
        cargarItemsListaDeseos(); // Actualiza la vista

        // Mostrar mensaje simple
        JOptionPane.showMessageDialog(this, "Productos agregados al carrito correctamente.", "Confirmación", JOptionPane.PLAIN_MESSAGE);
    }//GEN-LAST:event_btnEnviarAlCarritoActionPerformed

    private void btnVolverCatalogoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverCatalogoActionPerformed
        // TODO add your handling code here:
        this.dispose(); // Cierra el formulario del carrito
        // Si necesitas reabrir frmCliente, podrías hacerlo aquí:
        new frmCatalogo().setVisible(true);
    }//GEN-LAST:event_btnVolverCatalogoActionPerformed

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
        Sesion.usuarioActivo.guardarCarritoEnArchivo(); 
        Sesion.usuarioActivo.guardarListaDeseosEnArchivo(); // Guarda también la lista de deseos
        Sesion.usuarioActivo = null; 
        frmLogin login = new frmLogin();
        login.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnLogoutActionPerformed

    private void btnWishlistActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnWishlistActionPerformed
        // TODO add your handling code here:
        // Abre el formulario del carrito
        frmCarrito carritoFrame = new frmCarrito();
        carritoFrame.setVisible(true);
        // Opcional: puedes cerrar esta ventana si quieres que el carrito sea la única visible
        this.dispose();
    }//GEN-LAST:event_btnWishlistActionPerformed

    /**
     * @param args the command line arguments
     */
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
 public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmWishList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmWishList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmWishList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmWishList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                if (modelo.Sesion.usuarioActivo == null) {
                    // Crea un usuario de prueba con ID 1 y rol "Cliente"
                    modelo.Sesion.usuarioActivo = new modelo.Usuario(1, "testuser", "password"); 
                }
                new frmWishList().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel EastPanel;
    private javax.swing.JScrollPane JScrollPaneProductos;
    private javax.swing.JPanel TopPanelIcons;
    private javax.swing.JPanel WestPanel;
    private javax.swing.JButton btnEnviarAlCarrito;
    private javax.swing.JButton btnLimpiarCarrito;
    private javax.swing.JToggleButton btnLogout;
    private javax.swing.JButton btnVolverCatalogo;
    private javax.swing.JToggleButton btnWishlist;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jpanelBotones;
    private javax.swing.JPanel jpanelGeneral;
    private javax.swing.JPanel jpanelProductos;
    private javax.swing.JPanel panelAcciones;
    // End of variables declaration//GEN-END:variables
}
