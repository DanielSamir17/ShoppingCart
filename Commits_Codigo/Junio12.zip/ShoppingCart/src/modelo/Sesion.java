package modelo;

public class Sesion {
    public static Usuario usuarioActivo;
}
