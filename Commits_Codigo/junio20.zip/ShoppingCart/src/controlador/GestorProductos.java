package controlador;

import modelo.Producto;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class GestorProductos {

    private static final String RUTA_ARCHIVO = "src/Resources/Data/productos.txt";

    // Cargar productos desde el archivo
    public static List<Producto> cargarProductosDesdeArchivo() {
        List<Producto> lista = new ArrayList<>();

               File archivo = new File(RUTA_ARCHIVO);
             
        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split("\\|");
                if (partes.length == 3) {
                    String nombre = partes[0].trim();
                    double precio = Double.parseDouble(partes[1].trim());
                    String rutaImagen = partes[2].trim();

                    Producto p = new Producto(nombre, precio, rutaImagen);
                    lista.add(p);

                    System.out.println("Producto cargado: " + nombre);
                } else {
                    System.out.println("Línea mal formada: " + linea);
                }
            }
        } catch (Exception e) {
            System.out.println("Error al leer productos.txt: " + e.getMessage());
        }

        System.out.println(">>> Total productos cargados: " + lista.size());
        return lista;
    }

    // Crear archivo con productos por defecto si no existe
    public static void crearArchivoProductosSiNoExiste() {
        try {
            File archivo = new File(RUTA_ARCHIVO);
            archivo.getParentFile().mkdirs(); // crea carpetas si no existen

            PrintWriter pw = new PrintWriter(new FileWriter(archivo));
            pw.println("MousePad Java Commands|40000|/Resources/Icons/MousePad.png");
            pw.println("Mando Inalambrico RGB|120000|/Resources/Icons/Mando.png");
            pw.println("Teclado Mecanico 60%|150000|/Resources/Icons/Teclado.png");
            pw.println("Diademas Gamer|90000|/Resources/Icons/Diademas.png");
            pw.println("Monitor Gamer Curvado|600000|/Resources/Icons/Monitor.png");
            pw.println("Mouse Gamer RGB|75000|/Resources/Icons/Mouse.png");
            pw.close();

            System.out.println("Archivo productos.txt creado con datos iniciales.");
        } catch (IOException e) {
            System.out.println("Error al crear productos.txt: " + e.getMessage());
        }
    }
}
