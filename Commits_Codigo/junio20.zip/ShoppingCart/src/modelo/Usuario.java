package modelo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;

public class Usuario {
    public int id;
    public String user;
    public String contra;

    public Carrito carrito; // Ahora Carrito usará un Map
    public ListaDeseos listaDeseos;

    public Usuario(int id, String user, String contra) {
        this.id = id;
        this.user = user;
        this.contra = contra;
        this.carrito = new Carrito();
        this.listaDeseos = new ListaDeseos();
        cargarCarritoDesdeArchivo(); // Cargar el carrito al crear el usuario
        cargarListaDeseosDesdeArchivo(); // Cargar la lista de deseos al crear el usuario
    }

    public Usuario(String user, String contra) {
        this(0, user, contra);
    }

    public int getId() {
        return id;
    }

    public String getUser() {
        return user;
    }

    public String getContra() {
        return contra;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setContra(String contra) {
        this.contra = contra;
    }

    public Carrito getCarrito() {
        return carrito;
    }

    public ListaDeseos getListaDeseos() {
        return listaDeseos;
    }

    // --- Métodos de persistencia para Carrito ---
    public void guardarCarritoEnArchivo() {
        try {
            File archivo = new File("src/ArchivoTexto/" + user + "_carrito.txt");
            // Asegura que la carpeta exista
            File carpeta = new File("src/ArchivoTexto");
            if (!carpeta.exists()) {
                carpeta.mkdirs();
            }
            
            BufferedWriter bw = new BufferedWriter(new FileWriter(archivo));
            // Ahora guardamos el producto y su cantidad
            for (Map.Entry<Producto, Integer> entry : carrito.getProductosEnCarrito().entrySet()) {
                Producto p = entry.getKey();
                int cantidad = entry.getValue();
                bw.write(p.getNombre() + "," + p.getPrecio() + "," + p.getRutaImagen() + "," + cantidad);
                bw.newLine();
            }
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void cargarCarritoDesdeArchivo() {
        carrito.limpiarCarrito(); // limpia antes de cargar
        File archivo = new File("src/ArchivoTexto/" + user + "_carrito.txt");
        if (!archivo.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 4) { // Ahora esperamos 4 partes: nombre,precio,ruta,cantidad
                    String nombre = partes[0];
                    double precio = Double.parseDouble(partes[1]);
                    String ruta = partes[2];
                    int cantidad = Integer.parseInt(partes[3]);
                    carrito.agregarProducto(new Producto(nombre, precio, ruta), cantidad); // Agregamos con cantidad
                }
            }
        } catch (IOException | NumberFormatException e) {
            System.err.println("Error al cargar el carrito para " + user + ": " + e.getMessage());
            e.printStackTrace();
        }
    }

    // --- Métodos de persistencia para ListaDeseos (sin cambios significativos aquí) ---
    public void guardarListaDeseosEnArchivo() {
        try {
            File archivo = new File("src/ArchivoTexto/" + user + "_listaDeseos.txt");
             // Asegura que la carpeta exista
            File carpeta = new File("src/ArchivoTexto");
            if (!carpeta.exists()) {
                carpeta.mkdirs();
            }
            BufferedWriter bw = new BufferedWriter(new FileWriter(archivo));
            for (Producto p : listaDeseos.getProductos()) { // ListaDeseos sigue usando List<Producto>
                bw.write(p.getNombre() + "," + p.getPrecio() + "," + p.getRutaImagen());
                bw.newLine();
            }
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void cargarListaDeseosDesdeArchivo() {
        listaDeseos.limpiarListaDeseos();
        File archivo = new File("src/ArchivoTexto/" + user + "_listaDeseos.txt");
        if (!archivo.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 3) {
                    String nombre = partes[0];
                    double precio = Double.parseDouble(partes[1]);
                    String ruta = partes[2];
                    listaDeseos.agregarProducto(new Producto(nombre, precio, ruta));
                }
            }
        } catch (IOException | NumberFormatException e) {
            System.err.println("Error al cargar la lista de deseos para " + user + ": " + e.getMessage());
            e.printStackTrace();
        }
    }
}