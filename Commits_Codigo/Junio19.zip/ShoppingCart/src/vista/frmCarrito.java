package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import modelo.Carrito;
import modelo.Producto;
import modelo.Sesion;
import controlador.HistorialVentas;
// Importa frmCatalogo y frmListaDeseos si son necesarios

public class frmCarrito extends javax.swing.JFrame {

    private Carrito carrito;
    // Ya no necesitamos un mapa local 'cantidadesEnCarrito' si Carrito maneja las cantidades
    // private Map<Producto, Integer> cantidadesEnCarrito; 
    private HistorialVentas historialVentas; 

    public frmCarrito() {
        initComponents();
        this.setLocationRelativeTo(null);
        
        // El carrito del usuario activo ya maneja las cantidades
        carrito = Sesion.usuarioActivo.getCarrito(); 
        historialVentas = new HistorialVentas(); 
        
        cargarItemsCarrito();
    }

    private void actualizarTotal() {
        lblTotalPagar.setText("Total a pagar: $" + String.format("%,.2f", carrito.getTotal()));
    }

 private void cargarItemsCarrito() {
        jpanelProductos.removeAll();
        
        // Iterar sobre el mapa de productosEnCarrito para mostrar cada producto con su cantidad
        if (carrito.getProductosEnCarrito().isEmpty()) { 
            JLabel emptyLabel = new JLabel("El carrito está vacío.");
            emptyLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
            emptyLabel.setHorizontalAlignment(SwingConstants.CENTER);
            emptyLabel.setAlignmentX(CENTER_ALIGNMENT);
            jpanelProductos.add(emptyLabel);
        } else {
            for (Map.Entry<Producto, Integer> entry : carrito.getProductosEnCarrito().entrySet()) {
                Producto producto = entry.getKey();
                int cantidadInicial = entry.getValue();

                JPanel panelItem = new JPanel(new BorderLayout(10, 0));
                panelItem.setBackground(Color.WHITE);
                panelItem.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.LIGHT_GRAY));

                // Imagen
                JLabel lblImagen = new JLabel(new ImageIcon(
                        new ImageIcon(getClass().getResource(producto.getRutaImagen()))
                                .getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH)
                ));
                JPanel panelImagen = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
                panelImagen.setBackground(Color.WHITE);
                panelImagen.add(lblImagen);

                // Cantidad con botones
                JPanel panelCantidad = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
                panelCantidad.setBackground(Color.WHITE);
                
                JLabel lblCantidad = new JLabel(String.valueOf(cantidadInicial));
                lblCantidad.setPreferredSize(new Dimension(30, 25));
                lblCantidad.setHorizontalAlignment(SwingConstants.CENTER);

                JButton btnMenos = new JButton("–");
                JButton btnMas = new JButton("+");
                JButton btnEliminar = new JButton("X"); // Botón para eliminar el producto completamente

                panelCantidad.add(btnMenos);
                panelCantidad.add(lblCantidad);
                panelCantidad.add(btnMas);
                panelCantidad.add(btnEliminar);

                panelImagen.add(panelCantidad);
                panelItem.add(panelImagen, BorderLayout.WEST);

                // Detalles
                JPanel panelDetalles = new JPanel();
                panelDetalles.setBackground(Color.WHITE);
                panelDetalles.setLayout(new BoxLayout(panelDetalles, BoxLayout.Y_AXIS));
                panelDetalles.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 0));

                JLabel lblNombre = new JLabel("<html><b>" + producto.getNombre() + "</b></html>");
                lblNombre.setFont(new Font("Segoe UI", Font.BOLD, 14));
                panelDetalles.add(lblNombre);

                JLabel lblPrecio = new JLabel("$" + String.format("%,.2f", producto.getPrecio()));
                lblPrecio.setFont(new Font("Segoe UI", Font.PLAIN, 14));
                panelDetalles.add(lblPrecio);

                panelItem.add(panelDetalles, BorderLayout.CENTER);

                // Eventos para botones
                btnMas.addActionListener(e -> {
                    carrito.agregarProducto(producto); // Agrega una unidad
                    lblCantidad.setText(String.valueOf(carrito.getProductosEnCarrito().get(producto)));
                    Sesion.usuarioActivo.guardarCarritoEnArchivo();
                    actualizarTotal();
                });

                btnMenos.addActionListener(e -> {
                    if (carrito.getProductosEnCarrito().getOrDefault(producto, 0) > 0) {
                        carrito.quitarProducto(producto); // Quita una unidad
                        Integer cantidadRestante = carrito.getProductosEnCarrito().get(producto);
                        if (cantidadRestante == null || cantidadRestante == 0) {
                            cargarItemsCarrito(); // Recarga para remover el panel si la cantidad es 0
                        } else {
                            lblCantidad.setText(String.valueOf(cantidadRestante));
                        }
                        Sesion.usuarioActivo.guardarCarritoEnArchivo();
                        actualizarTotal();
                    }
                });
                
                btnEliminar.addActionListener(e -> {
                    carrito.eliminarProductoCompletamente(producto); // Elimina todas las unidades
                    Sesion.usuarioActivo.guardarCarritoEnArchivo();
                    cargarItemsCarrito(); // Recarga la vista para que el producto desaparezca
                });

                jpanelProductos.add(panelItem);
            }
        }

        actualizarTotal();
        jpanelProductos.revalidate();
        jpanelProductos.repaint();
    }
    @SuppressWarnings("unchecked")
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpanelGeneral = new javax.swing.JPanel();
        TopPanelIcons = new javax.swing.JPanel();
        WestPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        EastPanel = new javax.swing.JPanel();
        btnCart6 = new javax.swing.JToggleButton();
        btnLogout = new javax.swing.JToggleButton();
        JScrollPaneProductos = new javax.swing.JScrollPane();
        jpanelProductos = new javax.swing.JPanel();
        jpanelBotones = new javax.swing.JPanel();
        PanelTotal = new javax.swing.JPanel();
        lblTotalPagar = new javax.swing.JLabel();
        panelAcciones = new javax.swing.JPanel();
        btnFinalizarCompra = new javax.swing.JButton();
        btnVolverCatalogo = new javax.swing.JButton();
        btnLimpiarCarrito = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setMinimumSize(new java.awt.Dimension(620, 331));
        setPreferredSize(new java.awt.Dimension(700, 800));

        jpanelGeneral.setBackground(new java.awt.Color(255, 255, 255));
        jpanelGeneral.setPreferredSize(new java.awt.Dimension(800, 1000));
        jpanelGeneral.setLayout(new java.awt.BorderLayout());

        TopPanelIcons.setBackground(new java.awt.Color(255, 255, 255));
        TopPanelIcons.setPreferredSize(new java.awt.Dimension(800, 60));
        TopPanelIcons.setLayout(new java.awt.GridLayout(1, 2));

        WestPanel.setBackground(new java.awt.Color(255, 255, 255));
        WestPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/Icons/Carrito_Frame_60x60.png"))); // NOI18N
        WestPanel.add(jLabel1);

        TopPanelIcons.add(WestPanel);

        EastPanel.setBackground(new java.awt.Color(255, 255, 255));
        java.awt.FlowLayout flowLayout1 = new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT);
        flowLayout1.setAlignOnBaseline(true);
        EastPanel.setLayout(flowLayout1);

        btnCart6.setBackground(new java.awt.Color(255, 255, 255));
        btnCart6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/Icons/Wishlist_Clear.png"))); // NOI18N
        btnCart6.setPreferredSize(new java.awt.Dimension(38, 38));
        btnCart6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCart6ActionPerformed(evt);
            }
        });
        EastPanel.add(btnCart6);

        btnLogout.setBackground(new java.awt.Color(255, 255, 255));
        btnLogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/Icons/Logout_Clear.png"))); // NOI18N
        btnLogout.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        btnLogout.setPreferredSize(new java.awt.Dimension(38, 38));
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });
        EastPanel.add(btnLogout);

        TopPanelIcons.add(EastPanel);

        jpanelGeneral.add(TopPanelIcons, java.awt.BorderLayout.NORTH);

        JScrollPaneProductos.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        JScrollPaneProductos.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        JScrollPaneProductos.setPreferredSize(new java.awt.Dimension(800, 1000));

        jpanelProductos.setBackground(new java.awt.Color(255, 255, 255));
        jpanelProductos.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));
        jpanelProductos.setAutoscrolls(true);
        jpanelProductos.setPreferredSize(new java.awt.Dimension(800, 800));
        jpanelProductos.setLayout(new javax.swing.BoxLayout(jpanelProductos, javax.swing.BoxLayout.Y_AXIS));
        JScrollPaneProductos.setViewportView(jpanelProductos);

        jpanelGeneral.add(JScrollPaneProductos, java.awt.BorderLayout.CENTER);

        jpanelBotones.setBackground(new java.awt.Color(255, 255, 255));
        jpanelBotones.setLayout(new java.awt.BorderLayout());

        PanelTotal.setBackground(new java.awt.Color(255, 255, 255));
        PanelTotal.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        lblTotalPagar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblTotalPagar.setText("Total a pagar: $0.00");
        PanelTotal.add(lblTotalPagar);

        jpanelBotones.add(PanelTotal, java.awt.BorderLayout.LINE_START);

        panelAcciones.setBackground(new java.awt.Color(255, 255, 255));
        panelAcciones.setPreferredSize(new java.awt.Dimension(800, 70));
        panelAcciones.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnFinalizarCompra.setBackground(new java.awt.Color(255, 255, 255));
        btnFinalizarCompra.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnFinalizarCompra.setText("Finalizar compra");
        btnFinalizarCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFinalizarCompraActionPerformed(evt);
            }
        });
        panelAcciones.add(btnFinalizarCompra);

        btnVolverCatalogo.setBackground(new java.awt.Color(255, 255, 255));
        btnVolverCatalogo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVolverCatalogo.setText("Volver al catalogo");
        btnVolverCatalogo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverCatalogoActionPerformed(evt);
            }
        });
        panelAcciones.add(btnVolverCatalogo);

        btnLimpiarCarrito.setBackground(new java.awt.Color(255, 255, 255));
        btnLimpiarCarrito.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnLimpiarCarrito.setText("Limpiar Carrito");
        btnLimpiarCarrito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarCarritoActionPerformed(evt);
            }
        });
        panelAcciones.add(btnLimpiarCarrito);

        jpanelBotones.add(panelAcciones, java.awt.BorderLayout.LINE_END);

        jpanelGeneral.add(jpanelBotones, java.awt.BorderLayout.SOUTH);

        getContentPane().add(jpanelGeneral, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents
           

    private void btnLimpiarCarritoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarCarritoActionPerformed
        // TODO add your handling code here:
        carrito.limpiarCarrito();
        Sesion.usuarioActivo.guardarCarritoEnArchivo();
        cargarItemsCarrito(); // Actualiza la vista del carrito para que muestre "Carrito vacío"
    }//GEN-LAST:event_btnLimpiarCarritoActionPerformed

    private void btnFinalizarCompraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFinalizarCompraActionPerformed
        // TODO add your handling code here:
               if (carrito.estaVacio()) { // Usa el nuevo método estaVacio
            JOptionPane.showMessageDialog(this, "El carrito está vacío. Agrega productos para finalizar la compra.", "Carrito Vacío", JOptionPane.WARNING_MESSAGE);
            return;
        }

        double total = carrito.getTotal(); // Obtiene el total del carrito

        String nombreCliente = Sesion.usuarioActivo.getUser(); 

        // Agregar la venta al historial, pasando directamente el mapa de productos del carrito
        historialVentas.agregarVenta(nombreCliente, carrito.getProductosEnCarrito(), total);
        
        // Limpiar el carrito después de la compra
        carrito.limpiarCarrito();
        Sesion.usuarioActivo.guardarCarritoEnArchivo();
        cargarItemsCarrito(); 

        JOptionPane.showMessageDialog(this, "¡Compra finalizada con éxito!\nTotal: $" 
                + String.format("%,.2f", total),"Compra Exitosa", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnFinalizarCompraActionPerformed

    private void btnVolverCatalogoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverCatalogoActionPerformed
        // TODO add your handling code here:
        this.dispose(); // Cierra el formulario del carrito
        // Si necesitas reabrir frmCliente, podrías hacerlo aquí:
        new frmCatalogo().setVisible(true);
    }//GEN-LAST:event_btnVolverCatalogoActionPerformed

    private void btnCart6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCart6ActionPerformed

        // Abre el formulario del carrito
        frmWishList listadeseosFrame = new frmWishList();
        listadeseosFrame.setVisible(true);
        // Opcional: puedes cerrar esta ventana si quieres que el carrito sea la única visible
        this.dispose();
    }//GEN-LAST:event_btnCart6ActionPerformed

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
        Sesion.usuarioActivo.guardarCarritoEnArchivo(); 
        Sesion.usuarioActivo.guardarListaDeseosEnArchivo(); // Guarda también la lista de deseos
        Sesion.usuarioActivo = null; 
        frmLogin login = new frmLogin();
        login.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnLogoutActionPerformed

    /**
     * @param args the command line arguments
     */
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
 public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmCarrito.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmCarrito.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmCarrito.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmCarrito.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                if (modelo.Sesion.usuarioActivo == null) {
                    // Crea un usuario de prueba con ID 1 y rol "Cliente"
                    modelo.Sesion.usuarioActivo = new modelo.Usuario(1, "testuser", "password"); 
                }
                new frmCarrito().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel EastPanel;
    private javax.swing.JScrollPane JScrollPaneProductos;
    private javax.swing.JPanel PanelTotal;
    private javax.swing.JPanel TopPanelIcons;
    private javax.swing.JPanel WestPanel;
    private javax.swing.JToggleButton btnCart6;
    private javax.swing.JButton btnFinalizarCompra;
    private javax.swing.JButton btnLimpiarCarrito;
    private javax.swing.JToggleButton btnLogout;
    private javax.swing.JButton btnVolverCatalogo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jpanelBotones;
    private javax.swing.JPanel jpanelGeneral;
    private javax.swing.JPanel jpanelProductos;
    private javax.swing.JLabel lblTotalPagar;
    private javax.swing.JPanel panelAcciones;
    // End of variables declaration//GEN-END:variables
}
