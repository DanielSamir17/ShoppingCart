package modelo;

import java.util.ArrayList;
import java.util.List;

public class ListaDeseos {
    private List<Producto> productos;

    public ListaDeseos() {
        productos = new ArrayList<>();
    }

    public void agregarProducto(Producto producto) {
        productos.add(producto);
        System.out.println("Producto '" + producto.getNombre() + "' agregado a la lista de deseos.");
    }

    public List<Producto> getProductos() {
        return new ArrayList<>(productos);
    }

    public void limpiarListaDeseos() {
        productos.clear();
        System.out.println("Lista de deseos limpiada.");
    }

    public double getTotal() {
        double total = 0;
        for (Producto p : productos) {
            total += p.getPrecio();
        }
        return total;
    }
}

