package modelo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

public class Venta {
    private int idVenta;
    private LocalDateTime fechaCompra;
    private String nombreCliente;
    private Map<Producto, Integer> productosVendidos; // Producto y su cantidad
    private double totalVenta;

    public Venta(int idVenta, String nombreCliente, Map<Producto, Integer> productosVendidos, double totalVenta) {
        this.idVenta = idVenta;
        this.fechaCompra = LocalDateTime.now();
        this.nombreCliente = nombreCliente;
        this.productosVendidos = new HashMap<>(productosVendidos);
        this.totalVenta = totalVenta;
    }

    public Venta(int idVenta, String fechaCompraStr, String nombreCliente, Map<Producto, Integer> productosVendidos, double totalVenta) {
        this.idVenta = idVenta;
        this.fechaCompra = LocalDateTime.parse(fechaCompraStr, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        this.nombreCliente = nombreCliente;
        this.productosVendidos = new HashMap<>(productosVendidos);
        this.totalVenta = totalVenta;
    }
    
    // Getters
    public int getIdVenta() {
        return idVenta;
    }

    public LocalDateTime getFechaCompra() {
        return fechaCompra;
    }

    public String getFechaCompraFormateada() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return fechaCompra.format(formatter);
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public Map<Producto, Integer> getProductosVendidos() {
        return productosVendidos;
    }

    public double getTotalVenta() {
        return totalVenta;
    }
    
    public String getProductosVendidosAsString() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<Producto, Integer> entry : productosVendidos.entrySet()) {
            sb.append(entry.getKey().getNombre())
              .append(" (x")
              .append(entry.getValue())
              .append("), ");
        }
        if (sb.length() > 0) {
            sb.setLength(sb.length() - 2);
        }
        return sb.toString();
    }
}
