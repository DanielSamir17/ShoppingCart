package controlador;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList; // Necesitamos ArrayList
import java.util.List;     // Necesitamos List
import modelo.Nodo;
import modelo.Usuario;

public class PilaUsuarios {

    Nodo<Usuario> tope;
    private int nextId = 1; // Para IDs autoincrementales

    public PilaUsuarios() {
        tope = null;
    }

    public boolean getEsVacia() {
        return tope == null;
    }

    public Nodo<Usuario> getBase() {
        if (getEsVacia()) {
            return null;
        } else {
            Nodo<Usuario> p = tope;
            while (p.sig != tope) {
                p = p.sig;
            }
            return p;
        }
    }

    // Modificamos aggUsuario para que asigne el ID
    public void aggUsuario(String usuario, String contra) {
        Usuario user = new Usuario(nextId++, usuario, contra); // Asigna ID y luego incrementa
        Nodo<Usuario> nuevoNodo = new Nodo(user);

        if (getEsVacia()) {
            tope = nuevoNodo;
            tope.sig = tope;
        } else {
            nuevoNodo.sig = tope;
            Nodo<Usuario> ultimo = getBase();
            ultimo.sig = nuevoNodo;
            tope = nuevoNodo;
        }
        guardarUsuariosEnArchivo(); // Guarda automáticamente al agregar
    }
    
    // Método para agregar un usuario con un ID específico (usado al cargar del archivo)
    private void aggUsuarioConId(int id, String usuario, String contra) {
        Usuario user = new Usuario(id, usuario, contra);
        Nodo<Usuario> nuevoNodo = new Nodo(user);

        if (getEsVacia()) {
            tope = nuevoNodo;
            tope.sig = tope;
        } else {
            nuevoNodo.sig = tope;
            Nodo<Usuario> ultimo = getBase();
            ultimo.sig = nuevoNodo;
            tope = nuevoNodo;
        }
        if (id >= nextId) { // Asegura que nextId siempre sea el siguiente disponible
            nextId = id + 1;
        }
    }

    public boolean validacion(String usuario, String contra) {
        if (getEsVacia()) {
            return false;
        }
        Nodo<Usuario> p = tope;
        usuario = usuario.trim();
        contra = contra.trim();
        do {
            if (p.dato.user.equals(usuario) && p.dato.contra.equals(contra)) {
                return true;
            }
            p = p.sig;
        } while (p != tope);
        return false;
    }

    public Usuario obtenerUsuario(String usuario, String contra) {
        if (getEsVacia()) {
            return null;
        }

        Nodo<Usuario> p = tope;
        usuario = usuario.trim();
        contra = contra.trim();

        do {
            if (p.dato.user.equals(usuario) && p.dato.contra.equals(contra)) {
                return p.dato;
            }
            p = p.sig;
        } while (p != tope);

        return null;
    }
    
    // Nuevo método para buscar usuario por ID
    public Usuario buscarUsuarioPorId(int id) {
        if (getEsVacia()) {
            return null;
        }
        Nodo<Usuario> p = tope;
        do {
            if (p.dato.getId() == id) {
                return p.dato;
            }
            p = p.sig;
        } while (p != tope);
        return null;
    }

    // Nuevo método para modificar un usuario
    public boolean modificarUsuario(int id, String nuevoUsuario, String nuevaContra) {
        Nodo<Usuario> temp = tope;
        if (temp == null) {
            return false;
        }
        do {
            if (temp.dato.getId() == id) {
                temp.dato.setUser(nuevoUsuario);
                temp.dato.setContra(nuevaContra);
                guardarUsuariosEnArchivo(); // Guarda los cambios en el archivo
                return true;
            }
            temp = temp.sig;
        } while (temp != tope);
        return false;
    }
    
    // Nuevo método para obtener todos los usuarios como una lista
    public List<Usuario> obtenerTodosLosUsuarios() {
        List<Usuario> usuarios = new ArrayList<>();
        if (getEsVacia()) {
            return usuarios;
        }
        Nodo<Usuario> p = tope;
        do {
            usuarios.add(p.dato);
            p = p.sig;
        } while (p != tope);
        return usuarios;
    }


    public void guardarUsuariosEnArchivo() {
        try {
            File carpeta = new File("src/ArchivoTexto");
            if (!carpeta.exists()) {
                carpeta.mkdirs();
            }

            File archivo = new File(carpeta, "usuarios.txt");

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivo))) {
                if (!getEsVacia()) {
                    Nodo<Usuario> temp = tope;
                    do {
                        Usuario u = temp.dato;
                        // Ahora guardamos el ID también
                        writer.write(u.getId() + "," + u.user + "," + u.contra);
                        writer.newLine();
                        temp = temp.sig;
                    } while (temp != tope);
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void cargarUsuariosDesdeArchivo() {
        // Limpiamos la pila antes de cargar para evitar duplicados
        tope = null;
        nextId = 1; // Reiniciamos el ID al cargar
        
        File carpeta = new File("src/ArchivoTexto");
        File archivo = new File(carpeta, "usuarios.txt");

        if (!archivo.exists()) {
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(",");
                // Aseguramos que haya 3 partes (ID, usuario, contraseña)
                if (partes.length == 3) {
                    int id = Integer.parseInt(partes[0]);
                    String user = partes[1];
                    String contra = partes[2];
                    aggUsuarioConId(id, user, contra); // Usa el nuevo método para agregar con ID
                } else if (partes.length == 2) { // Compatibilidad con archivos antiguos sin ID
                    String user = partes[0];
                    String contra = partes[1];
                    aggUsuarioConId(nextId, user, contra); // Asigna un nuevo ID si no lo tiene
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (NumberFormatException e) {
            System.err.println("Error al parsear ID en el archivo de usuarios. Asegúrate de que el formato sea correcto.");
            e.printStackTrace();
        }
    }
}
