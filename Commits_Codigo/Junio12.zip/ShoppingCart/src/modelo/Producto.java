package modelo;

public class Producto {
    private String nombre;
    private double precio;
    private String rutaImagen; // Ruta relativa al classpath, ej: "/Resources/Icons/teclado.png"

    public Producto(String nombre, double precio, String rutaImagen) {
        this.nombre = nombre;
        this.precio = precio;
        this.rutaImagen = rutaImagen;
    }

    // Getters
    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public String getRutaImagen() {
        return rutaImagen;
    }

    // Puedes añadir setters si necesitas modificar la información del producto,
    // pero para este caso no serán necesarios.
}